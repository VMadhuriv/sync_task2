import java.util.Scanner;

// Interface to define database operations
interface Database {
    void connect();
    void disconnect();
    void saveSurveyResponse(String response);
}

// Implementation of SQL database
class SQLDatabase implements Database {
    @Override
    public void connect() {
        System.out.println("Connected to SQL database");
    }

    @Override
    public void disconnect() {
        System.out.println("Disconnected from SQL database");
    }

    @Override
    public void saveSurveyResponse(String response) {
        System.out.println("Saving survey response to SQL database: " + response);
    }
}

// Implementation of NoSQL database
class NoSQLDatabase implements Database {
    @Override
    public void connect() {
        System.out.println("Connected to NoSQL database");
    }

    @Override
    public void disconnect() {
        System.out.println("Disconnected from NoSQL database");
    }

    @Override
    public void saveSurveyResponse(String response) {
        System.out.println("Saving survey response to NoSQL database: " + response);
    }
}

// Main class for the Online Survey System
public class OnlineSurveySystem {
    private static final String PROMPT = "Enter your response (type 'exit' to finish): ";

    public static void main(String[] args) {
        Database database;
        Scanner scanner = new Scanner(System.in);

        // Choose database type
        System.out.println("Choose database type:");
        System.out.println("1. SQL");
        System.out.println("2. NoSQL");
        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline character
        if (choice == 1) {
            database = new SQLDatabase();
        } else {
            database = new NoSQLDatabase();
        }

        // Connect to the chosen database
        database.connect();

        // Gather survey responses
        System.out.println("Welcome to the Online Survey System");
        System.out.println("Please submit your responses (you can remain anonymous)");

        String response;
        while (true) {
            System.out.print(PROMPT);
            response = scanner.nextLine();
            if (response.equals("exit")) {
                break;
            }
            // Save response to the chosen database
            database.saveSurveyResponse(response);
        }

        // Disconnect from the database
        database.disconnect();

        System.out.println("Thank you for participating in the survey!");
    }
}
